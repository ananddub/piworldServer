"use strict";
let stringValue = "hello world";
console.log(stringValue.includes("world"));
