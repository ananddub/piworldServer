const db: number[] = [1, 3, 5, 6, 7];

for (let x of db) {
    console.log("v :", x);
}
